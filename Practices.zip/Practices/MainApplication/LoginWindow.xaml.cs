﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MainApplication
{
    /// <summary>
    /// Логика взаимодействия для LoginWindow.xaml
    /// </summary>
    public partial class LoginWindow : Page
    {
        public LoginWindow()
        {
            InitializeComponent();
        }

        public void LoginAdminClick(object sender, RoutedEventArgs e)
        {
            var password = Password.Password;
            var login = Login.Text;

            if (password == "123" || login == "admin")
            {
                MainProperties.loginType = LoginType.Admin;
                MainProperties.window.Title = "Список регистраций на курс" + " - Админ";
                MainProperties.frame.Navigate(new RegistrationWindow());
            }
            else
            {
                MessageBox.Show("Неверный пароль или логин");
            }
        }

        public void LoginGuestClick(object sender, RoutedEventArgs e)
        {
            MainProperties.loginType = LoginType.Guest;

            MessageBox.Show("Был выполнен вход как гость");

            MainProperties.window.Title = "Список регистраций на курс" + " - Гость";

            MainProperties.frame.Navigate(new RegistrationWindow());
        }
    }
}
