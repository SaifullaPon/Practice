﻿using System.Windows;
using System.Windows.Controls;

namespace MainApplication;

public static class MainProperties
{
    public static Window window;

    public static Frame frame;
    public static LoginType loginType;
}

public enum LoginType
{
    Guest,
    Admin
}
