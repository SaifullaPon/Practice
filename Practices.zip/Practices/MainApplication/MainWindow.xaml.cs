﻿using System.Windows;
using System.Windows.Controls;
using Persistence.Models;
using Persistence.Repositories;

namespace MainApplication;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
   

    public MainWindow()
    {
        InitializeComponent();
        MainProperties.frame = this.MainFrame;
        MainProperties.window = this;
        this.MainFrame.Navigate(new LoginWindow());
        this.Title = "Фитнес центр, вход";
    }
}