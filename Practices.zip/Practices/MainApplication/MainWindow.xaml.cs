﻿using System.Windows;
using System.Windows.Controls;
using Persistence.Models;
using Persistence.Repositories;

namespace MainApplication;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
    private readonly CourseRegistrationRepository _repository = new();
    private readonly TrainerRepository _trainerRepository = new();

    public MainWindow()
    {
        InitializeComponent();

        CmbSelectTrainer.ItemsSource = _trainerRepository.GetAsync().Result;
        DataGridRegistration.ItemsSource = _repository.GetAsync().Result;
    }

    private void BtnAddClick(object sender, RoutedEventArgs e)
    {
        var newRegistration = new CourseRegistration();
        var win = new WindowCourseRegistration(newRegistration);
        win.ShowDialog();
        DataGridRegistration.ItemsSource = _repository.GetAsync().Result;
    }

    private async void BtnDeleteClick(object sender, RoutedEventArgs e)
    {
        var row = DataGridRegistration.SelectedItem as CourseRegistration;

        if (row == null)
        {
            MessageBox.Show("Строка не выбрана");
            return;
        }

        MessageBoxResult result = MessageBox.Show("Вы уверены", "Вопрос", MessageBoxButton.YesNoCancel, MessageBoxImage.Question);
        if (result == MessageBoxResult.Yes)
        {
            await _repository.DeleteAsync(row.Id);
            DataGridRegistration.ItemsSource = await _repository.GetAsync();
        }
    }

    private async void BtnFilterClick(object sender, RoutedEventArgs e)
    {
        DataGridRegistration.ItemsSource = await _repository.GetAsync(isDone: true);
    }

    private async void CmbSelectTrainerSelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (CmbSelectTrainer.SelectedItem == null) 
            return;

        var currentTrainer = (Trainer)CmbSelectTrainer.SelectedItem;
        DataGridRegistration.ItemsSource = await _repository.GetAsync(currentTrainer.Name);
    }

    private async void BtnCancelClick(object sender, RoutedEventArgs e)
    {
        DataGridRegistration.ItemsSource = await _repository.GetAsync();
    }


    private async void BtnEditClick(object sender, RoutedEventArgs e)
    {
        var button = sender as Button;
        var currentRegistration = button.DataContext as CourseRegistration;
        var win = new WindowCourseRegistration(currentRegistration);
        win.ShowDialog();
        DataGridRegistration.ItemsSource = await _repository.GetAsync();
    }
}