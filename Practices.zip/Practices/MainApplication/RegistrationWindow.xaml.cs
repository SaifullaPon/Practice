﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Persistence.Models;
using Persistence.Repositories;

namespace MainApplication;

/// <summary>
/// Логика взаимодействия для RegistrationWindow.xaml
/// </summary>
public partial class RegistrationWindow : Page
{
    private readonly CourseRegistrationRepository _repository = new();
    private readonly TrainerRepository _trainerRepository = new();

    public RegistrationWindow()
    {
        InitializeComponent();
        DataGridRegistration.ItemsSource = _repository.GetAsync().Result;
    }

	private void BtnLeaveClick(object sender, RoutedEventArgs e)
	{
        MainProperties.frame.GoBack();
	}

	private void BtnAddClick(object sender, RoutedEventArgs e)
    {
        if (MainProperties.loginType != LoginType.Admin)
        {
            MessageBox.Show("Доступно только для админа");
            return;
        }

        var newRegistration = new CourseRegistration();
        var win = new WindowCourseRegistration(newRegistration);
        win.ShowDialog();
        DataGridRegistration.ItemsSource = _repository.GetAsync().Result;
    }

    private async void BtnDeleteClick(object sender, RoutedEventArgs e)
    {
        if (MainProperties.loginType != LoginType.Admin)
        {
            MessageBox.Show("Доступно только для админа");
            return;
        }

        var row = DataGridRegistration.SelectedItem as CourseRegistration;

        if (row == null)
        {
            MessageBox.Show("Строка не выбрана");
            return;
        }

        MessageBoxResult result = MessageBox.Show("Вы уверены", "Вопрос", MessageBoxButton.YesNoCancel, MessageBoxImage.Question);
        if (result == MessageBoxResult.Yes)
        {
            await _repository.DeleteAsync(row.Id);
            DataGridRegistration.ItemsSource = await _repository.GetAsync();
        }
    }

    private async void BtnFilterClick(object sender, RoutedEventArgs e)
    {
        DataGridRegistration.ItemsSource = await _repository.GetAsync(isDone: true);
    }

    private async void BtnCancelClick(object sender, RoutedEventArgs e)
    {
        DataGridRegistration.ItemsSource = await _repository.GetAsync();
    }
    private async void BtnAcceptClick(object sender, RoutedEventArgs e)
    {
        var currentTrainer = TrainerName.Text;
        DataGridRegistration.ItemsSource = await _repository.GetAsync(currentTrainer);
    }


    private async void BtnEditClick(object sender, RoutedEventArgs e)
    {
        if (MainProperties.loginType != LoginType.Admin)
        {
            MessageBox.Show("Доступно только для админа");
            return;
        }

        var button = sender as Button;
        var currentRegistration = button.DataContext as CourseRegistration;
        var win = new WindowCourseRegistration(currentRegistration);
        win.ShowDialog();
        DataGridRegistration.ItemsSource = await _repository.GetAsync();
    }
}
