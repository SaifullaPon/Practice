﻿using Persistence.Models;
using Persistence.Repositories;
using System.Windows;

namespace MainApplication;

/// <summary>
/// Логика взаимодействия для WindowCourseRegistration.xaml
/// </summary>
public partial class WindowCourseRegistration : Window
{
    private CourseRegistration _courseRegistration;

    private readonly CourseRegistrationRepository _repository = new();

    private readonly CourseRepository _courseRepository = new();

    private readonly TrainerRepository _trainerRepository = new();

    public WindowCourseRegistration(CourseRegistration courseRegistration)
    {
        InitializeComponent();
        _courseRegistration = courseRegistration;
        CmbCourse.ItemsSource = _courseRepository.GetAsync().Result;
        CmbTrainer.ItemsSource = _trainerRepository.GetAsync().Result;

        this.DataContext = courseRegistration;
    }

    private async void BtnSaveClick(object sender, RoutedEventArgs e)
    {
        if (!_repository.Validate(_courseRegistration))
            return;

        _courseRegistration.CourseId = _courseRegistration.Course.Id;
        _courseRegistration.TrainerId = _courseRegistration.Trainer.Id;

        if (datePicker.SelectedDate is DateTime dateTime)
            _courseRegistration.CreatedDate = DateOnly.FromDateTime(dateTime);

        if (_courseRegistration.Id == 0)
            await _repository.AddAsync(_courseRegistration);
        else
            await _repository.UpdateAsync(_courseRegistration);

        this.Close();
    }
}
