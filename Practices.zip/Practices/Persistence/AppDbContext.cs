﻿using Microsoft.EntityFrameworkCore;
using Persistence.Models;

namespace Persistence;

public class AppDbContext : DbContext
{
    public AppDbContext()
    {
        //Database.EnsureDeleted();
        //Database.EnsureCreated();
    }

    public DbSet<Course> Coursers { get; set; }
    public DbSet<Trainer> Trainers { get; set; }
    public DbSet<CourseRegistration> CourseRegistration { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(AppDbContext).Assembly);

        var course = new Course()
        {
            Id = 1,
            Name = "Design"
        };

        var course2 = new Course()
        {
            Id = 2,
            Name = "Programming"
        };

        var course3 = new Course()
        {
            Id = 3,
            Name = "Testing"
        };

        modelBuilder.Entity<Course>().HasData(course, course2, course3);


        var trainer = new Course()
        {
            Id = 1,
            Name = "Andrey"
        };

        var trainer2 = new Course()
        {
            Id = 2,
            Name = "Olga"
        };

        var trainer3 = new Course()
        {
            Id = 3,
            Name = "Petya"
        };

        modelBuilder.Entity<Trainer>().HasData(trainer, trainer2, trainer3);


        base.OnModelCreating(modelBuilder);
    }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseSqlite("Data Source=db.sql");
    }
}
