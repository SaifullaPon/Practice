﻿namespace Persistence.Models;

public class CourseRegistration
{
    public int Id { get; set; }

    public int TrainerId { get; set; }

    public int CourseId { get; set; }

    public DateOnly CreatedDate { get; set; }

    public bool IsDone { get; set; }

    public int TotalPoint { get; set; }

    public string? CertificateImage { get; set; }

    public string Comment { get; set; }


    public Trainer Trainer { get; set; }

    public Course Course { get; set; }
}
