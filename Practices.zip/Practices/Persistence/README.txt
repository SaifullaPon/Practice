перезапуск если не компилируется
команда если ошибка - dotnet restore --source \\build\NugetFeed --source https://api.nuget.org/v3/index.json --verbosity n
