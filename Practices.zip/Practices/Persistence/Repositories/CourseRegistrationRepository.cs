﻿using System.Windows;
using Microsoft.EntityFrameworkCore;
using Persistence.Models;

namespace Persistence.Repositories;

public class CourseRegistrationRepository
{
    public async Task AddAsync(CourseRegistration courseRegistration)
    {
        var dbContext = new AppDbContext();

        dbContext.CourseRegistration.Attach(courseRegistration);

        await dbContext.AddAsync(courseRegistration);
        await dbContext.SaveChangesAsync();
    }

    public async Task<List<CourseRegistration>> GetAsync(string? name = null, bool isDone = false)
    {
        var dbContext = new AppDbContext();

        var query = dbContext.CourseRegistration
            .Include(x => x.Course)
            .Include(x => x.Trainer);

        if (!string.IsNullOrEmpty(name))
            return await query.Where(x => x.Trainer.Name.Contains(name)).ToListAsync();

        if (isDone == true)
            return await query.Where(x => x.IsDone).ToListAsync();

        return await query.ToListAsync();
    }

    public async Task UpdateAsync(CourseRegistration courseRegistration)
    {
        var dbContext = new AppDbContext();

        dbContext.CourseRegistration.Update(courseRegistration);
        await dbContext.SaveChangesAsync();
    }

    public async Task DeleteAsync(int id)
    {
        var dbContext = new AppDbContext();

        await dbContext.CourseRegistration
            .Where(x => x.Id == id)
            .ExecuteDeleteAsync();
    }

    public bool Validate(CourseRegistration courseRegistration)
    {
        if (string.IsNullOrEmpty(courseRegistration.Comment))
        {
            MessageBox.Show($"{nameof(courseRegistration.Comment)} не может быть пустым");

            return false;
        }
        if (courseRegistration.Course == null)
        {
            MessageBox.Show("Курс не выбран");

            return false;
        }
        if (courseRegistration.Trainer == null)
        {
            MessageBox.Show("Тренер не выбран");

            return false;
        }

        return true;
    }
}
