﻿using Microsoft.EntityFrameworkCore;
using Persistence.Models;

namespace Persistence.Repositories;

public class CourseRepository
{
    public async Task AddAsync(string name)
    {
        var dbContext = new AppDbContext();

        var course = new Course()
        {
            Name = name
        };

        await dbContext.AddAsync(course);
        await dbContext.SaveChangesAsync();
    }

    public async Task<List<Course>> GetAsync()
    {
        var dbContext = new AppDbContext();

        return await dbContext.Coursers
            .AsNoTracking()
            .ToListAsync();
    }
}
