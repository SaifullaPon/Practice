﻿using Microsoft.EntityFrameworkCore;
using Persistence.Models;

namespace Persistence.Repositories;

public class TrainerRepository
{
    public async Task AddAsync(string name)
    {
        var dbContext = new AppDbContext();

        var trainer = new Trainer()
        {
            Name = name
        };

        await dbContext.AddAsync(trainer);
        await dbContext.SaveChangesAsync();
    }


    public async Task<List<Trainer>> GetAsync()
    {
        var dbContext = new AppDbContext();

        return await dbContext.Trainers
            .AsNoTracking()
            .ToListAsync();
    }
}
